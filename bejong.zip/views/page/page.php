<?php

use app\components\Menu;
/* @var $this yii\web\View */

$this->title = 'My Yii Application';
// var_dump($model);
require_once __DIR__ . '/template/template.php';
?>
