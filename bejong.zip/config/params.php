<?php

return [
    'adminEmail' => 'admin@example.com',
    'basePath' => dirname(__DIR__),
];
