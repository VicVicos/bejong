<p><span>Имя:</span> <?= $model->name ?></p>
<p><span>Email:</span> <?= $model->email ?></p>
<p><span>Вопрос:</span> <?= $model->question ?></p>
