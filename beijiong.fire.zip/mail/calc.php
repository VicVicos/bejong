<p><span>Имя:</span> <?= $model->name ?></p>
<p><span>Email:</span> <?= $model->email ?></p>
<p><span>Телефон:</span> <?= $model->contact ?></p>
<p><span>Вес:</span> <?= $model->weight ?></p>
<p><span>Ширина:</span> <?= $model->width ?></p>
<p><span>Длина:</span> <?= $model->length ?></p>
<p><span>Высота:</span> <?= $model->height ?></p>
<p><span>Тип:</span> <?= $model->type ?></p>
