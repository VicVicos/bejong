<p>
    Ошибка отправки сообщения cron.
    <?php
        var_dump($data);
    ?>
</p>
