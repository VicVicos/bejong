<?php
use app\components\Menu;

$this->title = 'My Yii Application';

require_once __DIR__ . '/template/template.php';
?>
