<?php
use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
use yii\widgets\Breadcrumbs;

$this->title = "Админочка"
?>
    <section class="container">
        <h1><?= Html::encode($this->title) ?></h1>
    </section>
</div>
<div class="container">

    <div class="row lk">
        <p>
            Здесь будет информация в админке.
        </p>
    </div>
</div>
