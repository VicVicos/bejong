<?php
//
// return [
//     'class' => 'yii\db\Connection',
//     'dsn' => 'mysql:host=itb-dev.ru;dbname=bejong',
//     'username' => 'bejong',
//     'password' => 'Be6FDUng',
//     'charset' => 'utf8',
//     'tablePrefix' => 'bj_'
// ];
return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=bejong_db',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
    'tablePrefix' => 'bj_'
];
