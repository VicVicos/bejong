<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%article}}".
 * Модель статей
 * @property integer $id
 * @property string $title
 * @property string $alias
 * @property string $type
 * @property string $link
 * @property string $intro
 * @property string $text
 * @property string $img
 * @property string $excerpt
 */
class Article extends \yii\db\ActiveRecord
{
    public $fileImage;
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%article}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['text', 'intro'], 'string'],
            [['title', 'alias', 'link', 'img', 'excerpt'], 'string', 'max' => 255],
            [['type', 'status'], 'string'],
        ];
    }

    /**
     * @ Id
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'title' => 'Заголовок',
            'alias' => 'Alias',
            'link' => 'Ссылка',
            'type' => 'Тип',
            'status' => 'Статус',
            'intro' => 'Интро текст',
            'text' => 'Статья',
            'img' => 'Картинка',
            'excerpt' => 'Особое описание',
        ];
    }
    // Методы работы со статьями

    /**
     * NOTE: Получать список из базы
     * Получаем типы статей
     * @method getType
     * @return array  Типы статей
     */
    public static function getType($type)
    {
        return static::find()->where(['type' => $type])->all();

    }
    /**
     * Дела перед сохранением статьи
     * @method beforeSave
     * @param  [type]     $insert [description]
     * @return [type]             [description]
     */
    public function beforeSave($insert)
    {
        $art = Yii::$app->request->post('Article');
        $this->type = $art['type'];
        if (parent::beforeSave($insert)) {
            // ...custom code here...
            return true;
        } else {
            return false;
        }
    }

    public function getFileSize($name)
    {
        $puthFile = Yii::$app->params['basePath'] . '/web/img/upload/' . $name;
        if (file_exists($puthFile)) {
            return false;
            // return filesize($name);
        } else {
            return false;
        }
    }
}
